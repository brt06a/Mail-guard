# MailGuard OSS - Complete Build Plan

## Phase 1: Project Foundation
- [x] Create monorepo structure with npm workspaces
- [x] Create root package.json with workspaces config
- [x] Create TypeScript configurations
- [x] Create .env.example file
- [x] Create docker-compose.yml for local development
- [x] Create railway.toml for deployment

## Phase 2: Packages Core
- [x] Create packages/core structure
- [x] Implement Prisma schema with all models
- [x] Implement AES-256-GCM encryption (encrypt/decrypt functions)
- [x] Implement OTP generation with crypto.randomInt
- [x] Implement OTP verification with bcrypt
- [x] Implement rate limiting logic
- [x] Create shared types and constants
- [x] Implement Zod environment validation

## Phase 3: Packages SMTP
- [x] Create packages/smtp structure
- [x] Implement ProviderDetector class
- [x] Implement provider map (gmail, outlook, zoho, yahoo)
- [x] Implement unknown domain probing
- [x] Create Nodemailer wrapper with credential decryption

## Phase 4: Apps API
- [x] Create apps/api structure
- [x] Implement Fastify server with plugins
- [x] Implement auth middleware (API key validation)
- [x] Implement rate limiting middleware
- [x] Implement POST /api/v1/otp/send endpoint
- [x] Implement POST /api/v1/otp/verify endpoint
- [x] Implement GET /health endpoint
- [x] Implement security headers middleware
- [x] Implement HTTPS enforcement
- [x] Create Dockerfile

## Phase 5: Apps Worker
- [x] Create apps/worker structure
- [x] Implement BullMQ queue setup
- [x] Implement email job processor
- [x] Implement OTP cleanup repeatable job
- [x] Implement Telegram notification job
- [x] Implement graceful shutdown
- [x] Create Dockerfile

## Phase 6: Apps Bot
- [x] Create apps/bot structure
- [x] Implement grammY bot with admin gate middleware
- [x] Implement /start command
- [x] Implement /addemail wizard (2-field)
- [x] Implement /newproject wizard
- [x] Implement /setotp command
- [x] Implement /genkey command
- [x] Implement /senders, /projects, /keys commands
- [x] Implement /logs command
- [x] Implement notification message builders
- [x] Create Dockerfile

## Phase 7: SDKs
- [ ] Create packages/sdk-js (JavaScript/TypeScript SDK)
- [ ] Create packages/sdk-python (Python SDK)
- [ ] Create packages/sdk-php (PHP SDK)
- [ ] Create packages/sdk-go (Go SDK)

## Phase 8: Testing
- [ ] Create unit tests for packages/core
- [ ] Create integration tests for API
- [ ] Create bot tests

## Phase 9: Documentation & Final Files
- [ ] Create README.md
- [ ] Create SECURITY.md
- [ ] Create LICENSE (MIT)